import React, { useState } from 'react';
import { Check } from 'lucide-react';

interface PricingTier {
  title: string;
  price: {
    monthly: number;
    yearly: number;
  };
  description: string;
  features: string[];
  cta: string;
  highlighted: boolean;
}

const tiers: PricingTier[] = [
  {
    title: "Free",
    price: {
      monthly: 0,
      yearly: 0
    },
    description: "Perfect for trying out RoboCreate's basic features",
    features: [
      "10 AI image generations per month",
      "5 AI video generations per month",
      "Basic Workshop Mode tools",
      "720p export resolution",
      "Access to 50+ templates",
      "Single user"
    ],
    cta: "Get Started",
    highlighted: false
  },
  {
    title: "Pro",
    price: {
      monthly: 19,
      yearly: 190
    },
    description: "For creators who need more power and features",
    features: [
      "Unlimited AI image generations",
      "30 AI video generations per month",
      "Full Workshop Mode access",
      "4K export resolution",
      "Access to all templates",
      "Priority processing",
      "Remove background feature",
      "Magic resize feature",
      "Up to 3 users"
    ],
    cta: "Try Free for 14 Days",
    highlighted: true
  },
  {
    title: "Business",
    price: {
      monthly: 49,
      yearly: 490
    },
    description: "For teams and businesses with advanced needs",
    features: [
      "Everything in Pro, plus:",
      "Unlimited AI video generations",
      "8K export resolution",
      "Brand kit management",
      "Advanced collaboration tools",
      "Priority support",
      "API access",
      "Custom templates",
      "Up to 10 users"
    ],
    cta: "Contact Sales",
    highlighted: false
  }
];

const Pricing: React.FC = () => {
  const [yearly, setYearly] = useState(false);
  
  return (
    <section id="pricing" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-900">
            Simple, Transparent Pricing
          </h2>
          <p className="text-lg text-gray-600 mb-8">
            Choose the plan that works for your creative needs
          </p>
          
          {/* Billing toggle */}
          <div className="flex items-center justify-center mb-8">
            <span className={`text-sm font-medium ${!yearly ? 'text-gray-900' : 'text-gray-500'}`}>
              Monthly
            </span>
            <button 
              onClick={() => setYearly(!yearly)}
              className="relative mx-4 inline-flex h-6 w-11 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent bg-gray-200 transition-colors duration-200 ease-in-out focus:outline-none"
              role="switch"
              aria-checked={yearly}
            >
              <span 
                className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                  yearly ? 'translate-x-5' : 'translate-x-0'
                }`}
              />
            </button>
            <span className={`text-sm font-medium ${yearly ? 'text-gray-900' : 'text-gray-500'}`}>
              Yearly <span className="text-blue-500 font-semibold">(Save 20%)</span>
            </span>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {tiers.map((tier) => (
            <div 
              key={tier.title}
              className={`rounded-2xl overflow-hidden border ${
                tier.highlighted 
                  ? 'border-blue-500 shadow-lg shadow-blue-100' 
                  : 'border-gray-200 shadow'
              }`}
            >
              {tier.highlighted && (
                <div className="bg-blue-500 text-white text-center py-2 text-sm font-semibold">
                  Most Popular
                </div>
              )}
              
              <div className="p-8">
                <h3 className="text-xl font-bold text-gray-900">{tier.title}</h3>
                <div className="mt-4 flex items-baseline">
                  <span className="text-4xl font-extrabold text-gray-900">
                    ${yearly ? tier.price.yearly : tier.price.monthly}
                  </span>
                  <span className="ml-1 text-xl font-semibold text-gray-500">
                    {yearly ? '/year' : '/month'}
                  </span>
                </div>
                <p className="mt-2 text-gray-600">{tier.description}</p>
                
                <ul className="mt-6 space-y-4">
                  {tier.features.map((feature, idx) => (
                    <li key={idx} className="flex items-start">
                      <div className="flex-shrink-0">
                        <Check className="h-5 w-5 text-blue-500" />
                      </div>
                      <p className="ml-3 text-gray-600">{feature}</p>
                    </li>
                  ))}
                </ul>
                
                <div className="mt-8">
                  <button
                    className={`w-full py-3 px-4 rounded-lg font-medium ${
                      tier.highlighted
                        ? 'bg-blue-500 text-white hover:bg-blue-600'
                        : 'bg-gray-100 text-gray-900 hover:bg-gray-200'
                    } transition-colors`}
                  >
                    {tier.cta}
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-12 text-center">
          <p className="text-gray-500">
            All plans include access to basic AI features. Features will remain free for 5 years.
          </p>
        </div>
      </div>
    </section>
  );
};

export default Pricing;