import React, { useState } from 'react';

interface Template {
  id: number;
  title: string;
  category: string;
  thumbnail: string;
  isNew: boolean;
}

const CATEGORIES = ["All", "Social Media", "Presentations", "Marketing", "Video", "Logos"];

const TEMPLATES: Template[] = [
  {
    id: 1,
    title: "Instagram Story Template",
    category: "Social Media",
    thumbnail: "https://images.pexels.com/photos/5417678/pexels-photo-5417678.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    isNew: true
  },
  {
    id: 2,
    title: "Corporate Presentation",
    category: "Presentations",
    thumbnail: "https://images.pexels.com/photos/7147454/pexels-photo-7147454.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    isNew: false
  },
  {
    id: 3,
    title: "Product Promo Video",
    category: "Video",
    thumbnail: "https://images.pexels.com/photos/16015857/pexels-photo-16015857/free-photo-of-close-up-of-a-camera-lens.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    isNew: true
  },
  {
    id: 4,
    title: "Facebook Ad Template",
    category: "Marketing",
    thumbnail: "https://images.pexels.com/photos/7709087/pexels-photo-7709087.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    isNew: false
  },
  {
    id: 5,
    title: "Minimal Logo Design",
    category: "Logos",
    thumbnail: "https://images.pexels.com/photos/6386956/pexels-photo-6386956.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    isNew: false
  },
  {
    id: 6,
    title: "YouTube Thumbnail",
    category: "Social Media",
    thumbnail: "https://images.pexels.com/photos/7974/pexels-photo.jpg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    isNew: true
  },
  {
    id: 7,
    title: "Sales Pitch Deck",
    category: "Presentations",
    thumbnail: "https://images.pexels.com/photos/8127803/pexels-photo-8127803.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    isNew: false
  },
  {
    id: 8,
    title: "Animated Social Story",
    category: "Video",
    thumbnail: "https://images.pexels.com/photos/13916254/pexels-photo-13916254.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    isNew: true
  }
];

const Templates: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState("All");

  const filteredTemplates = activeCategory === "All" 
    ? TEMPLATES 
    : TEMPLATES.filter(template => template.category === activeCategory);

  return (
    <section id="templates" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-900">
            Start with Professional Templates
          </h2>
          <p className="text-lg text-gray-600">
            Choose from hundreds of ready-made templates or let AI generate custom designs for you
          </p>
        </div>

        {/* Category filter tabs */}
        <div className="flex flex-wrap justify-center gap-2 mb-12">
          {CATEGORIES.map((category) => (
            <button
              key={category}
              onClick={() => setActiveCategory(category)}
              className={`px-5 py-2 rounded-full text-sm font-medium transition-colors ${
                activeCategory === category
                  ? 'bg-blue-500 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              {category}
            </button>
          ))}
        </div>

        {/* Templates grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {filteredTemplates.map((template) => (
            <div 
              key={template.id} 
              className="group relative rounded-xl overflow-hidden shadow-md hover:shadow-xl transition-all duration-300"
            >
              <div className="aspect-[3/4] overflow-hidden">
                <img 
                  src={template.thumbnail} 
                  alt={template.title}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
              </div>
              
              {/* Overlay with info */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-4">
                <h3 className="text-white font-semibold text-lg">{template.title}</h3>
                <p className="text-gray-300 text-sm">{template.category}</p>
                <button className="mt-3 bg-white text-blue-600 py-1 px-3 text-sm rounded-lg font-medium hover:bg-blue-50 transition-colors">
                  Use Template
                </button>
              </div>
              
              {/* New badge */}
              {template.isNew && (
                <div className="absolute top-3 right-3 bg-blue-500 text-white text-xs font-bold px-2 py-1 rounded-full">
                  NEW
                </div>
              )}
            </div>
          ))}
        </div>

        {/* View more button */}
        <div className="text-center mt-12">
          <button className="px-6 py-2 border border-gray-300 rounded-lg text-gray-700 font-medium hover:bg-gray-50 transition-colors">
            View All Templates
          </button>
        </div>
      </div>
    </section>
  );
};

export default Templates;