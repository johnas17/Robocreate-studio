import React from 'react';
import { 
  Wand2, 
  Layers, 
  PaintBucket, 
  Image, 
  Video, 
  Users, 
  Scissors, 
  LayoutGrid 
} from 'lucide-react';

interface FeatureProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  gradient: string;
}

const FeatureCard: React.FC<FeatureProps> = ({ icon, title, description, gradient }) => {
  return (
    <div className="bg-white rounded-xl shadow-md hover:shadow-lg transition-shadow p-6 border border-gray-100 group">
      <div className={`p-3 rounded-full w-14 h-14 flex items-center justify-center mb-4 ${gradient} text-white group-hover:scale-110 transition-transform`}>
        {icon}
      </div>
      <h3 className="text-xl font-semibold mb-2 text-gray-800">{title}</h3>
      <p className="text-gray-600">{description}</p>
    </div>
  );
};

const Features: React.FC = () => {
  const features: FeatureProps[] = [
    {
      icon: <Wand2 className="h-6 w-6" />,
      title: "Generative AI Engine",
      description: "Turn text into stunning images and videos with our advanced AI. Simply describe what you need, and watch it come to life.",
      gradient: "bg-gradient-to-r from-blue-500 to-indigo-600"
    },
    {
      icon: <Layers className="h-6 w-6" />,
      title: "Workshop Mode",
      description: "Professional editing tools for both images and videos. Includes layers, masks, content-aware editing, and vector drawing.",
      gradient: "bg-gradient-to-r from-purple-500 to-pink-500"
    },
    {
      icon: <PaintBucket className="h-6 w-6" />,
      title: "Brand Kits",
      description: "Save your brand colors, fonts, and logos for consistent output across all your creative projects.",
      gradient: "bg-gradient-to-r from-amber-500 to-orange-500"
    },
    {
      icon: <Scissors className="h-6 w-6" />,
      title: "Auto Background Removal",
      description: "Instantly remove backgrounds from images and videos with a single click, powered by advanced AI technology.",
      gradient: "bg-gradient-to-r from-green-500 to-emerald-500"
    },
    {
      icon: <LayoutGrid className="h-6 w-6" />,
      title: "Magic Resize",
      description: "Auto-resize your content for Instagram, YouTube, TikTok, and more while preserving the important elements.",
      gradient: "bg-gradient-to-r from-rose-500 to-red-500"
    },
    {
      icon: <Users className="h-6 w-6" />,
      title: "Real-time Collaboration",
      description: "Work together with your team in real-time, with comments, version control, and shared workspaces.",
      gradient: "bg-gradient-to-r from-cyan-500 to-blue-500"
    },
    {
      icon: <Image className="h-6 w-6" />,
      title: "Text-to-Image",
      description: "Generate professional-quality images from text descriptions for any use case or style.",
      gradient: "bg-gradient-to-r from-violet-500 to-purple-500"
    },
    {
      icon: <Video className="h-6 w-6" />,
      title: "Text-to-Video",
      description: "Create animated videos with audio from text prompts. Add narration, music, and subtitles automatically.",
      gradient: "bg-gradient-to-r from-blue-500 to-cyan-500"
    }
  ];

  return (
    <section id="features" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-900">
            All-in-One Creative AI Platform
          </h2>
          <p className="text-lg text-gray-600">
            Combine the power of AI generation with professional editing tools, all in your browser
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <FeatureCard
              key={index}
              icon={feature.icon}
              title={feature.title}
              description={feature.description}
              gradient={feature.gradient}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;