import React from 'react';

const RobotIcon: React.FC<{ className?: string }> = ({ className = "w-32 h-32" }) => {
  return (
    <div className={`relative ${className}`}>
      {/* Robot head base - metallic silver gradient */}
      <div className="absolute inset-0 rounded-2xl bg-gradient-to-b from-gray-200 to-gray-400 shadow-lg">
        {/* Head shape with subtle details */}
        <div className="absolute top-3 left-3 right-3 bottom-8 rounded-xl bg-gradient-to-br from-gray-300 to-gray-500"></div>
        
        {/* Antenna */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 w-1 h-8 bg-gray-600 rounded-full">
          <div className="absolute top-0 w-3 h-3 -translate-x-1/3 bg-blue-500 rounded-full animate-pulse"></div>
        </div>
        
        {/* Left eye - Camera lens (circular with blue details) */}
        <div className="absolute top-1/3 left-1/4 w-8 h-8 bg-gray-800 rounded-full flex items-center justify-center overflow-hidden">
          <div className="w-5 h-5 bg-blue-400 rounded-full"></div>
          <div className="absolute w-3 h-3 bg-blue-300 rounded-full"></div>
          <div className="absolute w-2 h-1 bg-white rounded-full opacity-60 -translate-x-1/4 -translate-y-1/4"></div>
        </div>
        
        {/* Right eye - Paint drop icon */}
        <div className="absolute top-1/3 right-1/4 w-8 h-8 bg-gray-800 rounded-full flex items-center justify-center">
          <div className="w-4 h-6 bg-blue-500 rounded-t-full transform rotate-45"></div>
          <div className="absolute w-1 h-1 bg-white rounded-full top-3 right-3"></div>
        </div>
        
        {/* Mouth - minimal design */}
        <div className="absolute bottom-6 left-1/2 -translate-x-1/2 w-10 h-1 bg-gray-700 rounded-full"></div>
      </div>
    </div>
  );
};

export default RobotIcon;