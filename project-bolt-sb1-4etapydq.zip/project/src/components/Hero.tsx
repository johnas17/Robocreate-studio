import React, { useState, useEffect } from 'react';
import { PlayCircle, Sparkles } from 'lucide-react';
import RobotIcon from './RobotIcon';

const LOADING_PHRASES = [
  "Initializing AI canvas...",
  "Gathering creative inspiration...",
  "Preparing digital paintbrush...",
  "Activating robot imagination...",
  "Connecting to creative cloud..."
];

const EXAMPLE_PROMPTS = [
  "A serene lake at sunset with mountains in the background",
  "A futuristic cityscape with flying cars and neon lights",
  "A cute cartoon robot painting on a canvas",
  "An animated logo for a tech startup with dynamic elements"
];

const Hero: React.FC = () => {
  const [loadingPhrase, setLoadingPhrase] = useState(LOADING_PHRASES[0]);
  const [currentPromptIndex, setCurrentPromptIndex] = useState(0);
  const [prompt, setPrompt] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);
  
  // Cycle through loading phrases
  useEffect(() => {
    const interval = setInterval(() => {
      const randIndex = Math.floor(Math.random() * LOADING_PHRASES.length);
      setLoadingPhrase(LOADING_PHRASES[randIndex]);
    }, 2000);
    
    return () => clearInterval(interval);
  }, []);
  
  // Cycle through example prompts
  useEffect(() => {
    const typePrompt = async () => {
      const nextPrompt = EXAMPLE_PROMPTS[currentPromptIndex];
      setPrompt("");
      
      // Type out the prompt character by character
      for (let i = 0; i < nextPrompt.length; i++) {
        await new Promise(resolve => setTimeout(resolve, 50));
        setPrompt(prev => prev + nextPrompt.charAt(i));
      }
      
      // Wait before clearing and moving to next prompt
      await new Promise(resolve => setTimeout(resolve, 3000));
      
      // Move to next prompt
      setCurrentPromptIndex((prevIndex) => (prevIndex + 1) % EXAMPLE_PROMPTS.length);
    };
    
    typePrompt();
  }, [currentPromptIndex]);
  
  const handleGenerate = () => {
    setIsGenerating(true);
    // Simulate generation for 3 seconds
    setTimeout(() => {
      setIsGenerating(false);
    }, 3000);
  };
  
  return (
    <section className="min-h-screen pt-20 pb-16 relative overflow-hidden bg-gradient-to-br from-gray-50 to-gray-100">
      {/* Background elements - animated dots/particles */}
      <div className="absolute inset-0 overflow-hidden">
        {[...Array(20)].map((_, i) => (
          <div 
            key={i}
            className="absolute rounded-full bg-blue-500 opacity-10"
            style={{
              width: Math.random() * 20 + 5 + 'px',
              height: Math.random() * 20 + 5 + 'px',
              top: Math.random() * 100 + '%',
              left: Math.random() * 100 + '%',
              animationDuration: Math.random() * 10 + 20 + 's',
              animationDelay: Math.random() * 5 + 's',
              animation: 'float infinite ease-in-out'
            }}
          />
        ))}
      </div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="flex flex-col lg:flex-row items-center justify-between gap-12">
          {/* Left side - Text content */}
          <div className="lg:w-1/2 text-center lg:text-left">
            <div className="inline-flex items-center px-3 py-1 rounded-full bg-blue-100 text-blue-600 mb-6">
              <Sparkles className="h-4 w-4 mr-2" />
              <span className="text-sm font-medium">AI-Powered Creation Studio</span>
            </div>
            
            <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-gray-800 via-blue-700 to-indigo-800 bg-clip-text text-transparent">
              Unleash Your AI-Powered Creativity
            </h1>
            
            <p className="text-lg md:text-xl text-gray-600 mb-8 max-w-xl mx-auto lg:mx-0">
              Transform your ideas into stunning visuals with our browser-based AI studio. 
              No downloads, no installations—just creative freedom in the cloud.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <button
                className="px-8 py-3 bg-gradient-to-r from-blue-500 to-indigo-600 text-white rounded-lg font-medium hover:opacity-90 transition-opacity flex items-center justify-center"
                onClick={() => window.location.href = '#workflow'}
              >
                Start Creating
              </button>
              
              <button
                className="px-8 py-3 bg-transparent border border-gray-300 text-gray-700 rounded-lg font-medium hover:bg-gray-50 transition-colors flex items-center justify-center"
              >
                <PlayCircle className="h-5 w-5 mr-2" />
                Watch Demo
              </button>
            </div>
          </div>
          
          {/* Right side - Interactive preview */}
          <div className="lg:w-1/2 rounded-xl shadow-xl bg-white p-6 max-w-md w-full">
            <div className="flex items-center mb-4">
              <RobotIcon className="w-10 h-10" />
              <div className="ml-3">
                <h3 className="font-semibold text-lg">RoboCreate AI</h3>
                <p className="text-sm text-gray-500">Ready to bring your ideas to life</p>
              </div>
            </div>
            
            <div className="relative mb-4">
              <input
                type="text"
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="Describe what you want to create..."
                className="w-full rounded-lg border border-gray-300 px-4 py-3 pr-12 focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-700"
              />
              <button 
                className="absolute right-2 top-1/2 -translate-y-1/2 text-blue-500 hover:text-blue-600"
                onClick={handleGenerate}
              >
                <Sparkles className="h-6 w-6" />
              </button>
            </div>
            
            {/* Preview area */}
            <div className="aspect-video rounded-lg overflow-hidden relative bg-gray-100 flex items-center justify-center mb-3">
              {isGenerating ? (
                <div className="text-center">
                  <div className="flex justify-center mb-2">
                    <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-blue-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                  </div>
                  <p className="text-sm text-gray-600">{loadingPhrase}</p>
                </div>
              ) : (
                <div className="text-center p-4">
                  <RobotIcon className="w-20 h-20 mx-auto mb-3" />
                  <p className="text-gray-500">Enter a prompt and click the magic wand to generate</p>
                </div>
              )}
            </div>
            
            <div className="text-xs text-gray-500">
              Try prompts like: landscapes, characters, logos, product designs, or video concepts
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;