import React from 'react';
import { BookCheck, Zap, Globe } from 'lucide-react';
import RobotIcon from './RobotIcon';

const CTASection: React.FC = () => {
  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-gradient-to-br from-gray-900 to-blue-900 rounded-3xl overflow-hidden">
          <div className="grid grid-cols-1 lg:grid-cols-2">
            <div className="p-8 lg:p-12">
              <div className="flex items-center mb-6">
                <RobotIcon className="text-white h-14 w-14" />
                <h2 className="ml-4 text-3xl font-bold text-white">
                  Start Creating <span className="text-blue-300">Today</span>
                </h2>
              </div>
              
              <p className="text-blue-100 text-lg mb-8 max-w-md">
                Join thousands of creators, marketers, and designers who have transformed their creative workflow with RoboCreate Studio.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 mb-10">
                <button className="bg-blue-500 hover:bg-blue-600 text-white px-6 py-3 rounded-lg font-medium transition-colors flex items-center justify-center">
                  <Zap className="h-5 w-5 mr-2" />
                  Start Free Trial
                </button>
                <button className="bg-transparent border border-blue-300 text-blue-100 hover:bg-blue-800/30 px-6 py-3 rounded-lg font-medium transition-colors flex items-center justify-center">
                  <Globe className="h-5 w-5 mr-2" />
                  See Live Demo
                </button>
              </div>
              
              <div className="flex flex-col sm:flex-row gap-6">
                <div className="flex items-start">
                  <BookCheck className="h-5 w-5 text-blue-300 mt-1 flex-shrink-0" />
                  <p className="ml-3 text-blue-100">No credit card required</p>
                </div>
                <div className="flex items-start">
                  <BookCheck className="h-5 w-5 text-blue-300 mt-1 flex-shrink-0" />
                  <p className="ml-3 text-blue-100">Cancel anytime</p>
                </div>
                <div className="flex items-start">
                  <BookCheck className="h-5 w-5 text-blue-300 mt-1 flex-shrink-0" />
                  <p className="ml-3 text-blue-100">Free for 5 years</p>
                </div>
              </div>
            </div>
            
            <div className="hidden lg:block relative">
              <div className="absolute inset-0 bg-gradient-to-br from-blue-600/40 to-indigo-600/40 mix-blend-multiply"></div>
              <img
                src="https://images.pexels.com/photos/3861969/pexels-photo-3861969.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
                alt="Creator using RoboCreate Studio"
                className="h-full w-full object-cover"
              />
            </div>
          </div>
        </div>
        
        {/* Owner's note */}
        <div className="mt-20 text-center max-w-3xl mx-auto">
          <h3 className="text-2xl font-bold text-gray-900 mb-4">A Message from Our Team</h3>
          <p className="text-gray-600 mb-6">
            RoboCreate Studio is designed to empower creators of all skill levels. Our AI technologies are constantly improving, with updates every three months to ensure you always have access to the latest capabilities. We're committed to keeping our core features free for the next 5 years.
          </p>
          <div className="flex items-center justify-center">
            <RobotIcon className="w-10 h-10" />
            <div className="ml-3 text-left">
              <p className="font-medium text-gray-900">The RoboCreate Team</p>
              <p className="text-sm text-gray-500">Building the future of creative AI</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CTASection;