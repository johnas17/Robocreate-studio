import React from 'react';
import { MessageSquare, Sparkles, Pencil, Share2 } from 'lucide-react';
import RobotIcon from './RobotIcon';

const steps = [
  {
    icon: <MessageSquare className="h-6 w-6" />,
    title: "Describe Your Idea",
    description: "Type or speak your creative concept. Be as detailed or as simple as you want.",
    color: "bg-blue-500"
  },
  {
    icon: <Sparkles className="h-6 w-6" />,
    title: "AI Generates Content",
    description: "Our AI instantly creates images or videos based on your description.",
    color: "bg-purple-500"
  },
  {
    icon: <Pencil className="h-6 w-6" />,
    title: "Enter Workshop Mode",
    description: "Refine your creation with our professional editing tools.",
    color: "bg-orange-500"
  },
  {
    icon: <Share2 className="h-6 w-6" />,
    title: "Share & Collaborate",
    description: "Publish directly to social platforms or collaborate with your team.",
    color: "bg-green-500"
  }
];

const Workflow: React.FC = () => {
  return (
    <section id="workflow" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-900">
            How RoboCreate Works
          </h2>
          <p className="text-lg text-gray-600">
            From idea to finished creation in minutes, not hours
          </p>
        </div>

        <div className="relative">
          {/* Connecting line */}
          <div className="absolute hidden md:block top-24 left-0 right-0 h-0.5 bg-gray-200 z-0"></div>
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 relative z-10">
            {steps.map((step, index) => (
              <div key={index} className="flex flex-col items-center text-center">
                <div className={`${step.color} w-12 h-12 rounded-full flex items-center justify-center text-white mb-4`}>
                  {step.icon}
                </div>
                <h3 className="text-xl font-semibold mb-2 text-gray-800">{step.title}</h3>
                <p className="text-gray-600">{step.description}</p>
                
                {/* Arrow connector for mobile */}
                {index < steps.length - 1 && (
                  <div className="md:hidden w-8 h-8 my-4 text-gray-300">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
                    </svg>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Testimonial/Experience section */}
        <div className="mt-20 bg-white rounded-2xl shadow-xl overflow-hidden">
          <div className="grid grid-cols-1 lg:grid-cols-2">
            <div className="p-8 lg:p-12">
              <div className="flex items-center mb-6">
                <RobotIcon className="h-12 w-12" />
                <div className="ml-4">
                  <h3 className="text-xl font-bold text-gray-900">Experience the Future of Creation</h3>
                  <p className="text-gray-600">Web-based AI creative suite</p>
                </div>
              </div>
              
              <blockquote className="italic text-gray-700 mb-6">
                "RoboCreate Studio has completely transformed how I create content. What used to take me hours in Photoshop now takes minutes. The AI understands exactly what I need, and the Workshop Mode gives me all the fine-tuning controls I want."
              </blockquote>
              
              <div className="flex items-center">
                <img 
                  src="https://images.pexels.com/photos/1036623/pexels-photo-1036623.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
                  alt="Sarah Johnson" 
                  className="h-10 w-10 rounded-full object-cover"
                />
                <div className="ml-3">
                  <p className="font-medium text-gray-900">Sarah Johnson</p>
                  <p className="text-sm text-gray-500">Marketing Director, TechCorp</p>
                </div>
              </div>
            </div>
            
            <div className="bg-gradient-to-br from-blue-500 to-indigo-600 p-8 lg:p-12 text-white flex flex-col justify-center">
              <h3 className="text-2xl font-bold mb-4">Ready to transform your creative process?</h3>
              <p className="mb-6 opacity-90">Join thousands of creators who are already using RoboCreate Studio to bring their ideas to life.</p>
              <div>
                <button className="bg-white text-blue-600 px-6 py-3 rounded-lg font-medium hover:bg-blue-50 transition-colors">
                  Try Free for 14 Days
                </button>
                <p className="text-sm mt-2 opacity-75">No credit card required</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Workflow;